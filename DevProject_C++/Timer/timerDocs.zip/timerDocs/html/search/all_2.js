var searchData=
[
  ['setinterval',['setInterval',['../class_timer.html#a715e8f8bfdfef403aeb936b00e2c23a7',1,'Timer']]],
  ['start',['start',['../class_timer.html#a3a8b5272198d029779dc9302a54305a8',1,'Timer']]]
];
