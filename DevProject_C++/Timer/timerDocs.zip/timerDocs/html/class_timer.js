var class_timer =
[
    [ "Timer", "class_timer.html#aa1166e738309ae4acd331fa5f8dfa5f2", null ],
    [ "getInterval", "class_timer.html#a7249ba01dfccb5ede2a52fc934cf97c2", null ],
    [ "setInterval", "class_timer.html#a715e8f8bfdfef403aeb936b00e2c23a7", null ],
    [ "start", "class_timer.html#a3a8b5272198d029779dc9302a54305a8", null ],
    [ "onTickEvent", "class_timer.html#a85b88fc09ab0b0377d01b089b7fba98c", null ]
];